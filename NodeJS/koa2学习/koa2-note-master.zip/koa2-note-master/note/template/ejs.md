# ejs模板引擎

## 具体查看ejs官方文档
[https://github.com/mde/ejs](https://github.com/mde/ejs)